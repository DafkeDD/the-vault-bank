fx_version 'bodacious'
game 'gta5'

this_is_a_map 'yes'

data_file 'TIMECYCLEMOD_FILE' 'floky_timecycle.xml'
data_file 'AUDIO_GAMEDATA' 'floky_vaultbank_doors_sound_game.dat'

files {
  'floky_vaultbank_doors_sound_game.dat151.rel',
  'floky_timecycle.xml',
}